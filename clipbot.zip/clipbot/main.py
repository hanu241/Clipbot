import argparse
import logging
import time

from src.config import load_config
from src.state import State
from src.orchestrator import process_channel

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def run_once(cfg: dict, state: State) -> None:
    for channel in cfg["channels"]:
        process_channel(channel, cfg, state)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--once", action="store_true", help="Run a single check-and-process pass, then exit (use this with cron).")
    args = parser.parse_args()

    cfg = load_config(args.config)
    state = State(cfg["storage"]["state_file"])

    if args.once:
        run_once(cfg, state)
        return

    interval = cfg["poll_interval_minutes"] * 60
    while True:
        run_once(cfg, state)
        time.sleep(interval)


if __name__ == "__main__":
    main()
