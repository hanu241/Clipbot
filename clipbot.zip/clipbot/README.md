# ClipBot — auto-clip & auto-repost pipeline

Monitors given YouTube channels for new uploads, cuts them into vertical
highlight clips with AI-selected moments and burned-in captions, and posts
those clips to TikTok, Instagram Reels, and YouTube Shorts.

**Use this only for channels you own or have explicit agreements to repost
clips from.** Auto-downloading and republishing other people's videos
without permission is copyright infringement and a violation of YouTube's
Terms of Service, regardless of how the tool is built.

## How it works

```
YouTube channel(s) --> monitor.py (poll for new uploads)
                    --> downloader.py (yt-dlp)
                    --> transcriber.py (faster-whisper, word-level timestamps)
                    --> clip_finder.py (Claude picks highlight segments)
                    --> clipper.py (ffmpeg: cut, 9:16 crop, burn captions)
                    --> posters/{tiktok,instagram,youtube_shorts}.py
```

State (which videos are already processed) is tracked in `data/state.json`
so re-running never double-posts.

## 1. Install

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

You also need **ffmpeg** on the system PATH (`brew install ffmpeg` / `apt install ffmpeg`).

## 2. Get API credentials

| Service | What you need | Where |
|---|---|---|
| YouTube Data API | API key | console.cloud.google.com → enable "YouTube Data API v3" → Credentials |
| Anthropic | API key | console.anthropic.com |
| TikTok | Content Posting API access token | developers.tiktok.com — requires app review before you can post publicly; use `SELF_ONLY` privacy while testing |
| Instagram | Graph API long-lived access token + IG Business/Creator account | developers.facebook.com — also needs a public URL to host clips (S3, Cloudflare R2, or your own static file server) since IG pulls the video by URL |
| YouTube Shorts | OAuth client (`client_secret.json`) | Google Cloud Console → OAuth consent screen + Desktop app credentials |

Copy `config.example.yaml` → `config.yaml` and fill these in, plus the
channel IDs you're clipping.

## 3. Run it

**Option A — always-on process (simplest for continuous monitoring):**
```bash
python main.py --config config.yaml
```
Runs forever, checking every `poll_interval_minutes`.

**Option B — cron / scheduled task (cheaper, more controllable):**
```bash
python main.py --config config.yaml --once
```
Add to crontab to run every 15 min:
```
*/15 * * * * cd /path/to/clipbot && venv/bin/python main.py --once >> clipbot.log 2>&1
```

**Option C — small VPS with systemd** (recommended for reliability):
```ini
# /etc/systemd/system/clipbot.service
[Unit]
Description=ClipBot
After=network.target

[Service]
WorkingDirectory=/opt/clipbot
ExecStart=/opt/clipbot/venv/bin/python main.py --config config.yaml
Restart=always
RestartSec=30

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl enable --now clipbot
```

A $6–12/mo VPS (Hetzner, DigitalOcean) with 2+ vCPUs is enough for a handful
of channels. GPU is only worth it if you're processing dozens of hours of
video per day (see optimization below).

The **first run of YouTube Shorts posting** needs a one-time browser login
(`run_local_server`) to authorize the OAuth app — do that once on a machine
with a browser, then copy the resulting `youtube_token.json` to your server.

## 4. Optimizing it

**Cost/speed of transcription**
- `faster-whisper` with `model_size: "small"` + `compute_type: "int8"` on CPU is the sweet spot for cost — a 10-min video transcribes in roughly the time it takes to watch it.
- If you're processing many channels/videos per day, a small GPU box (e.g. an RTX 4000-class instance) with `compute_type: "float16"` cuts transcription time by 5-10x.
- Cache transcripts (`data/transcripts/<video_id>.json`) if you ever want to re-run clip selection with different parameters without re-transcribing.

**Cost of the LLM call**
- One `clip_finder` call per video is already cheap since it's a single text-in/JSON-out request; the main lever is not re-running it on the same video (state.json already prevents that).
- If a channel posts very long videos (podcasts, streams), consider trimming the transcript to the middle 80% before sending it, since intros/outros rarely contain clip-worthy moments.

**ffmpeg throughput**
- `-preset veryfast` (already set) trades a little file size for much faster encodes; bump to `medium` only if final quality matters more than turnaround time.
- If you have an NVIDIA GPU, swap `-c:v libx264` for `-c:v h264_nvenc` for hardware-accelerated encoding — several times faster on a multi-clip video.
- Process clips for one video in parallel (`concurrent.futures.ThreadPoolExecutor`) since ffmpeg calls are I/O + CPU bound and independent per clip.

**API quota / rate limits**
- YouTube Data API: `playlistItems.list` costs 1 quota unit per call, so polling every 15 min across many channels is cheap (default daily quota is 10,000 units).
- TikTok and Instagram both rate-limit posts per account per day — stagger postings rather than firing all clips from a video at once (add a short delay between `_post_to_platforms` calls if you're publishing many clips back-to-back).

**Scaling to many channels**
- Once you're past ~10-15 channels, replace the simple `for` loop in `orchestrator.py` with a task queue (Celery + Redis, or even a simple `multiprocessing.Pool`) so one slow video doesn't delay checking the rest.
- Move `data/downloads` and `data/clips` to a mounted volume or object storage if disk fills up — the code already deletes the source video after clipping, but consider also deleting clips from local disk once they've been confirmed posted.

## Notes on legal/ToS risk

- This pipeline downloads video via `yt-dlp`, which is not YouTube's official method and technically sits outside their Terms of Service even when you have the creator's permission to repurpose the content. Where possible, get raw files directly from the creators (many will just hand you a Drive/Dropbox link) instead of scraping their public uploads — it's cleaner legally and usually higher quality too.
- Keep your agreements with each creator on file — TikTok/Instagram/YouTube can and do take down content or suspend accounts over copyright disputes, agreement or not.
