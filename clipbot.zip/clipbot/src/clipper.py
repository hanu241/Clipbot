import os
import subprocess


def _build_srt(words: list[dict], clip_start: float, path: str, max_chars: int = 28) -> None:
    """Groups words into short caption lines timed relative to the clip start."""
    def fmt(t: float) -> str:
        h, rem = divmod(max(t, 0), 3600)
        m, s = divmod(rem, 60)
        ms = int((s - int(s)) * 1000)
        return f"{int(h):02d}:{int(m):02d}:{int(s):02d},{ms:03d}"

    lines, buf, buf_start = [], "", None
    for w in words:
        if buf_start is None:
            buf_start = w["start"]
        candidate = (buf + " " + w["word"]).strip()
        if len(candidate) > max_chars:
            lines.append((buf_start, w["start"], buf.strip()))
            buf, buf_start = w["word"], w["start"]
        else:
            buf = candidate
    if buf:
        lines.append((buf_start, words[-1]["end"] if words else buf_start + 1, buf.strip()))

    with open(path, "w") as f:
        for i, (start, end, text) in enumerate(lines, 1):
            f.write(f"{i}\n{fmt(start - clip_start)} --> {fmt(end - clip_start)}\n{text}\n\n")


def make_clip(source_path: str, clip: dict, segments: list[dict], out_dir: str, clip_id: str) -> str:
    """Cuts [clip['start'], clip['end']], reframes to 1080x1920, burns in captions."""
    start, end = clip["start"], clip["end"]
    out_path = os.path.join(out_dir, f"{clip_id}.mp4")
    srt_path = os.path.join(out_dir, f"{clip_id}.srt")

    words = [w for s in segments for w in s["words"] if start <= w["start"] < end]
    _build_srt(words, start, srt_path)

    vf = (
        "scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,"
        f"subtitles={srt_path}:force_style="
        "'FontName=Arial,FontSize=16,PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,BorderStyle=3,Outline=2,Alignment=2,MarginV=80'"
    )

    cmd = [
        "ffmpeg", "-y",
        "-ss", str(start), "-to", str(end),
        "-i", source_path,
        "-vf", vf,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "21",
        "-c:a", "aac", "-b:a", "128k",
        out_path,
    ]
    subprocess.run(cmd, check=True)
    os.remove(srt_path)
    return out_path
