import json
import re
from anthropic import Anthropic

PROMPT_TEMPLATE = """You are selecting short-form clip candidates from a video transcript for TikTok/Reels/Shorts.

Transcript (each line: [start-end] text):
{transcript}

Pick up to {max_clips} standalone segments that would work as short vertical clips.
Rules:
- Each clip must be between {min_sec} and {max_sec} seconds long.
- Prefer segments with a strong hook, a complete thought, a joke, or a surprising insight.
- Segments must not overlap.
- Use exact start/end times from the transcript lines (snap to the nearest line boundary).

Respond with ONLY a JSON array, no other text, in this exact shape:
[{{"start": 12.3, "end": 47.8, "hook_title": "short catchy title", "reason": "why this works"}}]
"""


def _format_transcript(segments: list[dict]) -> str:
    lines = [f"[{s['start']:.1f}-{s['end']:.1f}] {s['text']}" for s in segments]
    return "\n".join(lines)


def find_clips(segments: list[dict], api_key: str, max_clips: int, min_sec: int, max_sec: int) -> list[dict]:
    client = Anthropic(api_key=api_key)
    prompt = PROMPT_TEMPLATE.format(
        transcript=_format_transcript(segments),
        max_clips=max_clips,
        min_sec=min_sec,
        max_sec=max_sec,
    )

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}],
    )

    text = "".join(block.text for block in response.content if block.type == "text")
    match = re.search(r"\[.*\]", text, re.DOTALL)
    if not match:
        return []

    clips = json.loads(match.group(0))
    # basic sanity filtering
    return [
        c for c in clips
        if isinstance(c.get("start"), (int, float)) and isinstance(c.get("end"), (int, float))
        and c["end"] > c["start"]
    ]
