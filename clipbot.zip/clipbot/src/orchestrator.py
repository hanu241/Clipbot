import logging
import os

from . import monitor, downloader, transcriber, clip_finder, clipper
from .posters import tiktok, instagram, youtube_shorts

log = logging.getLogger("clipbot")


def process_channel(channel: dict, cfg: dict, state) -> None:
    channel_id, name = channel["channel_id"], channel["name"]
    api_keys = cfg["api_keys"]

    new_videos = monitor.find_new_videos(channel_id, api_keys["youtube_data_api_key"], state)
    if not new_videos:
        log.info("[%s] no new uploads", name)
        return

    for video in new_videos:
        log.info("[%s] processing new upload: %s", name, video["title"])
        try:
            _process_video(channel, video, cfg)
        except Exception:
            log.exception("[%s] failed on video %s - will retry next poll", name, video["video_id"])
            continue  # don't mark as processed, so it's retried next cycle
        state.mark_processed(channel_id, video["video_id"])


def _process_video(channel: dict, video: dict, cfg: dict) -> None:
    video_id = video["video_id"]
    src_path = downloader.download_video(video_id, cfg["storage"]["download_dir"])

    log.info("transcribing %s", video_id)
    segments = transcriber.transcribe(src_path, cfg["whisper"])

    log.info("finding clip-worthy moments in %s", video_id)
    clips = clip_finder.find_clips(
        segments,
        cfg["api_keys"]["anthropic_api_key"],
        max_clips=cfg["clips_per_video"],
        min_sec=cfg["min_clip_seconds"],
        max_sec=cfg["max_clip_seconds"],
    )
    log.info("found %d clip candidates for %s", len(clips), video_id)

    for i, clip in enumerate(clips):
        clip_id = f"{video_id}_{i}"
        clip_path = clipper.make_clip(src_path, clip, segments, cfg["storage"]["clips_dir"], clip_id)
        title = clip.get("hook_title", video["title"])
        _post_to_platforms(clip_path, title, channel["platforms"], cfg)

    # free disk space once every clip for this video is cut
    os.remove(src_path)


def _post_to_platforms(clip_path: str, title: str, platforms: list[str], cfg: dict) -> None:
    api_keys = cfg["api_keys"]

    if "tiktok" in platforms and api_keys["tiktok"].get("access_token"):
        try:
            tiktok.post_video(clip_path, title, api_keys["tiktok"]["access_token"])
            log.info("posted to TikTok: %s", title)
        except Exception:
            log.exception("TikTok post failed for %s", clip_path)

    if "instagram" in platforms and api_keys["instagram"].get("access_token"):
        try:
            base_url = api_keys["instagram"]["public_media_base_url"].rstrip("/")
            public_url = f"{base_url}/{os.path.basename(clip_path)}"
            instagram.post_reel(
                public_url, title, api_keys["instagram"]["ig_user_id"], api_keys["instagram"]["access_token"]
            )
            log.info("posted to Instagram: %s", title)
        except Exception:
            log.exception("Instagram post failed for %s", clip_path)

    if "youtube_shorts" in platforms:
        try:
            yt_cfg = api_keys["youtube_upload"]
            youtube_shorts.post_short(
                clip_path, title, "", yt_cfg["client_secret_file"], yt_cfg["token_file"]
            )
            log.info("posted to YouTube Shorts: %s", title)
        except Exception:
            log.exception("YouTube Shorts post failed for %s", clip_path)
