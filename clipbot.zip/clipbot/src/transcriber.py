from faster_whisper import WhisperModel

_model_cache = {}


def _get_model(model_size: str, device: str, compute_type: str) -> WhisperModel:
    key = (model_size, device, compute_type)
    if key not in _model_cache:
        _model_cache[key] = WhisperModel(model_size, device=device, compute_type=compute_type)
    return _model_cache[key]


def transcribe(video_path: str, whisper_cfg: dict) -> list[dict]:
    """Returns a list of segments: [{start, end, text, words: [{start, end, word}]}]"""
    model = _get_model(
        whisper_cfg["model_size"], whisper_cfg["device"], whisper_cfg["compute_type"]
    )
    segments, _info = model.transcribe(video_path, word_timestamps=True, vad_filter=True)

    result = []
    for seg in segments:
        result.append(
            {
                "start": seg.start,
                "end": seg.end,
                "text": seg.text.strip(),
                "words": [{"start": w.start, "end": w.end, "word": w.word} for w in (seg.words or [])],
            }
        )
    return result
