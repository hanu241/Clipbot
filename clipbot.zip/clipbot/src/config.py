import os
import yaml


def load_config(path: str = "config.yaml") -> dict:
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"'{path}' not found. Copy config.example.yaml to config.yaml and fill in your values."
        )
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)

    os.makedirs(cfg["storage"]["download_dir"], exist_ok=True)
    os.makedirs(cfg["storage"]["clips_dir"], exist_ok=True)
    os.makedirs(os.path.dirname(cfg["storage"]["state_file"]) or ".", exist_ok=True)

    return cfg
