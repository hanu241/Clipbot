import os
import requests

INIT_URL = "https://open.tiktokapis.com/v2/post/publish/video/init/"


def post_video(video_path: str, title: str, access_token: str) -> dict:
    """Direct-post a video to TikTok via the Content Posting API (chunked upload).
    Requires an approved TikTok app with the video.publish scope and a valid
    long-lived access_token obtained through TikTok's OAuth flow.
    """
    file_size = os.path.getsize(video_path)

    init_resp = requests.post(
        INIT_URL,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json; charset=UTF-8",
        },
        json={
            "post_info": {
                "title": title,
                "privacy_level": "SELF_ONLY",  # switch to PUBLIC_TO_EVERYONE once you've tested end to end
                "disable_duet": False,
                "disable_comment": False,
                "disable_stitch": False,
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": file_size,
                "chunk_size": file_size,
                "total_chunk_count": 1,
            },
        },
        timeout=30,
    )
    init_resp.raise_for_status()
    data = init_resp.json()["data"]
    upload_url = data["upload_url"]

    with open(video_path, "rb") as f:
        video_bytes = f.read()

    put_resp = requests.put(
        upload_url,
        headers={
            "Content-Type": "video/mp4",
            "Content-Range": f"bytes 0-{file_size - 1}/{file_size}",
        },
        data=video_bytes,
        timeout=120,
    )
    put_resp.raise_for_status()

    return {"publish_id": data.get("publish_id"), "status": "uploaded"}
