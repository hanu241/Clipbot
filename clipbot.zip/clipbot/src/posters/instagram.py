import time
import requests

GRAPH_API = "https://graph.facebook.com/v21.0"


def post_reel(public_video_url: str, caption: str, ig_user_id: str, access_token: str) -> dict:
    """Publishes a Reel to an Instagram Business/Creator account.
    Instagram requires the video to already be reachable at a public URL
    (host clips on S3/Cloudflare R2/your own server before calling this).
    """
    container_resp = requests.post(
        f"{GRAPH_API}/{ig_user_id}/media",
        data={
            "media_type": "REELS",
            "video_url": public_video_url,
            "caption": caption,
            "access_token": access_token,
        },
        timeout=30,
    )
    container_resp.raise_for_status()
    creation_id = container_resp.json()["id"]

    # video processing is async - poll until it's ready to publish
    for _ in range(30):
        status_resp = requests.get(
            f"{GRAPH_API}/{creation_id}",
            params={"fields": "status_code", "access_token": access_token},
            timeout=15,
        )
        status = status_resp.json().get("status_code")
        if status == "FINISHED":
            break
        if status == "ERROR":
            raise RuntimeError(f"Instagram failed to process container {creation_id}")
        time.sleep(5)

    publish_resp = requests.post(
        f"{GRAPH_API}/{ig_user_id}/media_publish",
        data={"creation_id": creation_id, "access_token": access_token},
        timeout=30,
    )
    publish_resp.raise_for_status()
    return publish_resp.json()
