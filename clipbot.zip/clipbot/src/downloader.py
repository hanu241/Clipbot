import os
import subprocess


def download_video(video_id: str, download_dir: str) -> str:
    """Downloads a YouTube video by ID, returns the local file path."""
    out_path = os.path.join(download_dir, f"{video_id}.mp4")
    if os.path.exists(out_path):
        return out_path

    url = f"https://www.youtube.com/watch?v={video_id}"
    cmd = [
        "yt-dlp",
        "-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]",
        "--merge-output-format", "mp4",
        "-o", out_path,
        url,
    ]
    subprocess.run(cmd, check=True)
    return out_path
