import json
import os


class State:
    """Tracks which video IDs have already been processed, per channel."""

    def __init__(self, path: str):
        self.path = path
        if os.path.exists(path):
            with open(path, "r") as f:
                self.data = json.load(f)
        else:
            self.data = {}

    def is_processed(self, channel_id: str, video_id: str) -> bool:
        return video_id in self.data.get(channel_id, [])

    def mark_processed(self, channel_id: str, video_id: str) -> None:
        self.data.setdefault(channel_id, []).append(video_id)
        # keep only the last 500 IDs per channel so the file doesn't grow forever
        self.data[channel_id] = self.data[channel_id][-500:]
        self._save()

    def _save(self) -> None:
        with open(self.path, "w") as f:
            json.dump(self.data, f, indent=2)
