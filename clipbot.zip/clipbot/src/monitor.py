import requests

YT_API = "https://www.googleapis.com/youtube/v3"


def get_uploads_playlist_id(channel_id: str, api_key: str) -> str:
    """Every channel has a hidden 'uploads' playlist - cheapest way to list its videos."""
    r = requests.get(
        f"{YT_API}/channels",
        params={"part": "contentDetails", "id": channel_id, "key": api_key},
        timeout=15,
    )
    r.raise_for_status()
    items = r.json().get("items", [])
    if not items:
        raise ValueError(f"No channel found for id {channel_id}")
    return items[0]["contentDetails"]["relatedPlaylists"]["uploads"]


def get_latest_videos(channel_id: str, api_key: str, max_results: int = 5) -> list[dict]:
    """Returns the most recent uploads: [{video_id, title, published_at}, ...] newest first."""
    playlist_id = get_uploads_playlist_id(channel_id, api_key)
    r = requests.get(
        f"{YT_API}/playlistItems",
        params={
            "part": "snippet",
            "playlistId": playlist_id,
            "maxResults": max_results,
            "key": api_key,
        },
        timeout=15,
    )
    r.raise_for_status()
    videos = []
    for item in r.json().get("items", []):
        snippet = item["snippet"]
        videos.append(
            {
                "video_id": snippet["resourceId"]["videoId"],
                "title": snippet["title"],
                "published_at": snippet["publishedAt"],
            }
        )
    return videos


def find_new_videos(channel_id: str, api_key: str, state) -> list[dict]:
    """Filters get_latest_videos down to ones not yet in state."""
    latest = get_latest_videos(channel_id, api_key)
    return [v for v in latest if not state.is_processed(channel_id, v["video_id"])]
